/*
不建议把数据分散在vault里，应当尽量把一个项目的数据整合在一个key
*/
var temp;
const numid = 4;
function hash(string){
    var md = forge.md.sha256.create();
    md.update(string);
    return md.digest().toHex();
}
class Vault {
    constructor(usr, pwd) {
        this.usr = usr;
        this.pwd = pwd;
        this.usr_hash = hash(usr);
        this.pwd_hash = hash(pwd);
    }
    // static Create(usr, pwd, data) {
    //     console.log("Creating vault...")
    //     const usr_hash = hash(usr);
    //     const pwd_hash = hash(pwd);
    //     console.log("usr hash:",usr_hash);
    //     console.log("pwd hash:",pwd_hash);

    //     download((str)=>{
    //         let storage = JSON.parse(str);
    //         console.log(storage);
    //         storage[usr_hash] = encryptDES(data,pwd_hash);
    //         console.log(storage);
    //         upload(JSON.stringify(storage),4)
    //     },numid)

    //     return new Vault(usr,pwd)
    // }
    /**
     * 重设数据
     * @param {prototype} data 对象，覆盖旧数据
     */
    set(data){
        download((str)=>{
            console.log(str);
            let storage = JSON.parse(str);
            console.log(storage);
            storage[this.usr_hash] = encryptDES("ok"+JSON.stringify(data),this.pwd_hash);
            upload(JSON.stringify(storage),4);
        },numid)
    }
    /**
     * 获取数据
     */
    get(){
        download((str)=>{
            console.log(str);
            let storage = JSON.parse(str);
            console.log(storage);
            let encrypted = storage[this.usr_hash];
            if(encrypted == undefined){
                alert("用户不存在");
                console.log("用户不存在 错误码:-1")
                return -1;
            }
            let usr_string = decryptDES(encrypted,this.pwd_hash);
            if(usr_string.slice(0,2) != "ok"){
                alert("密码错误");
                console.log("密码错误 错误码:-2")
                return -2;
            }
            let usr_data = JSON.parse(usr_string.slice(2));
            console.log(usr_data);
            // return usr_data;
            temp = usr_data
        },numid)
        while(temp==undefined){}
        return temp;
    }
    /**
     * 删除账户
     */
    del(data){
        download((str)=>{
            console.log(str);
            let storage = JSON.parse(str);
            console.log(storage);
            delete storage[this.usr_hash];
            upload(JSON.stringify(storage),4);
        },numid)
    }
};