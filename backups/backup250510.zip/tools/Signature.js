const Pigeon = (()=>{
// 生成新的密钥对
function generateNewKeyPair(bits) {
    const keypair = forge.pki.rsa.generateKeyPair({ bits , workers: 2});
    const privateKey = forge.pki.privateKeyToPem(keypair.privateKey);
    const publicKey = forge.pki.publicKeyToPem(keypair.publicKey);
    return { privateKey, publicKey };
}

// 签名函数
function sign(data, privateKey) {
    const key = forge.pki.privateKeyFromPem(privateKey);
    const md = forge.md.sha256.create();
    md.update(data, 'utf8');
    return key.sign(md);
}

// 验证函数
function verify(data, signature, publicKey) {
    const key = forge.pki.publicKeyFromPem(publicKey);
    const md = forge.md.sha256.create();
    md.update(data, 'utf8');
    return key.verify(md.digest().bytes(), signature);
}

// 示例用法
// const { privateKey, publicKey } = generateNewKeyPair();

// console.log('Private Key:', privateKey);
// console.log('Public Key:', publicKey);

// const data = `This is a test message.`;
// console.log("Data:", data);
// const signature = sign(data, privateKey);
// console.log('Signature:', signature);

// const verified = verify(data, signature, publicKey);
// console.log('Verification result:', verified);

class Pigeon{
    static generateNewKeyPair(){
        console.log("Generating new key pair... (long time cost)")
        return generateNewKeyPair(64);
    }
}
    return Pigeon;

})();