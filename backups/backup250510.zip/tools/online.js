//最多上传15000字符(最终长度,不是加密前)
/**
 * 
 * @param {String} data 字符串数据
 * @param {number} numid 文本库的id
 */
 function upload(data, numid) {
  // 对数据进行 base64 加密，处理 Unicode 字符
  const encoder = new TextEncoder();
  const encodedData = btoa(String.fromCharCode(...new Uint8Array(encoder.encode(data))));
  
  const url = `https://cn.apihz.cn/api/cunchu/textcc.php?id=10003632&key=2d28bb4369491dd93cccdb543de18b6e&type=1&numid=${numid}&words=${encodedData}`;
  
  fetch(url)
    .then(response => {
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      return response.json();
    })
    .then(data => {
      console.log('Upload successful:', data);
    })
    .catch(error => {
      console.error('Upload error:', error);
    });
}

/**
 * 
 * @param {Function} handler 接收data字符串的函数
 * @param {number} numid 文本库的id
 */
function download(handler, numid) {
  console.log("downloading...");
  const url = `https://cn.apihz.cn/api/cunchu/textcc.php?id=10003632&key=2d28bb4369491dd93cccdb543de18b6e&type=2&numid=${numid}`;
  
  fetch(url)
    .then(response => {
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      return response.json();
    })
    .then(obj => {
      if (obj.code === "400") {
        alert("淦，咱玩太快了，服务器ban了咱一分钟。如果你给我充会员咱俩就爽玩");
        throw new Error('Server returned error code 400');
      }
      return obj.words;
    })
    .then(words => {
      // 对数据进行 base64 解密，处理 Unicode 字符
      const decoder = new TextDecoder();
      const decodedData = decoder.decode(new Uint8Array([...atob(words)].map(c => c.charCodeAt(0))));
      handler(decodedData);
    })
    .catch(error => {
      console.error('Download error:', error);
    });
}